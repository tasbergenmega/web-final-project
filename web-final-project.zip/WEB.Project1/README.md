# I'm Restaurants — Final Project

**Students:** Tasbergen Medeu and Yergenbay Dias

## Tech Stack Overview
The project is built using plain JavaScript and jQuery, strictly separated by features to meet the course requirements.

### Plain JavaScript (`js/main.js`, `js/auth.js`, `js/order-success.js`)
- **Cart Logic:** Handled in `main.js`. Data is stored in `localStorage`, iterated using `reduce`, and rendered via `createElement`. 
- **Event Delegation:** Used on the `document` level to handle clicks on dynamically created `.add-to-cart` buttons using `event.target.closest()`.
- **Delivery & Order Forms:** Custom validation logic using standard DOM methods (no jQuery).
- **Auth UI:** Password toggle and dynamic checklist are handled in plain JS.

### jQuery (`js/menu.js`, `js/jquery-main.js`)
- **Menu:** Built dynamically from the `MENU_ITEMS` array. Uses jQuery `$.each`, chaining (`.addClass().attr().appendTo()`), and selectors.
- **Contact Form:** Validated using jQuery. Uses `.filter()` to target only the specific form, `.slideDown()` for error messages, and `.siblings()` for DOM traversal.

## Fixes Applied at Final Stage
1. Fixed jQuery validator crash on the delivery page by filtering out forms without a `#message` field.
2. Fixed order page validation scope (`[aria-invalid]` check now targets `.checkout-layout`).
3. Removed hardcoded cart counters (now dynamically generated).
4. Added visual state for Auth (Login/Logout) using `localStorage`.
5. Cleaned up dead code (removed `main.html`, `index.css`, unused variables, and console logs).